#TODO List

###Bugs
None so far.

###Features
1. √ ~~add code highlight.~~
2. √ ~~add hexo-tag-cloud support.~~
3. √ ~~expand the width of the page.~~
4. add doc about how to use hexo-tag-cloud.
5. try to modify the code highlight theme.
